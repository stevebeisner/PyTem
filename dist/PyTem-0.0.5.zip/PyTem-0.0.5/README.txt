# PyTem Template Engine.

PyTem is a small (single file) and simple Python-Server-Pages-like template engine
for Python 3+.

It can run from the command line or be imported into another Python 3 program.

It's current status is "Alpha", missing mostly: good documentation.

{
'sally': "Salty", 
'dick':  "Dick Tracy"
}
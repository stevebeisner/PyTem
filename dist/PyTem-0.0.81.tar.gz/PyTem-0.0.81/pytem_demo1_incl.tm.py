print("----- I'm inside an included template.")
godiva="dog"
print('godiva is '+str(eval('godiva'))+'.')
print('dick is still '+str(eval('dick'))+'.')
print('sally is '+str(eval('sally'))+'.')
print('----- Last line of included template.')
